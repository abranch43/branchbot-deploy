
import argparse, os, sys, json, subprocess, re
from pathlib import Path
import datetime

REPO_ROOT = Path.cwd()
AUDIT_DIR = REPO_ROOT / ".branchbot" / "audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

def audit(event, payload):
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    (AUDIT_DIR / f"{ts}_{event}.json").write_text(json.dumps(payload, indent=2))

def cmd_status(args):
    print("BranchBot Status")
    print(f"• Repo: {REPO_ROOT}")
    print(f"• Audit log: {AUDIT_DIR}")

def grep_repo(query):
    matches = []
    for root, _, files in os.walk(REPO_ROOT):
        if ".git" in root or ".branchbot" in root: 
            continue
        for fn in files:
            path = Path(root) / fn
            try:
                text = path.read_text(errors="ignore")
            except Exception:
                continue
            if query.lower() in text.lower():
                line_no = 0
                for i, line in enumerate(text.splitlines(), start=1):
                    if query.lower() in line.lower():
                        matches.append({"file": str(path.relative_to(REPO_ROOT)), "line": i, "text": line.strip()})
    return matches

def cmd_find(args):
    res = grep_repo(args.query)
    audit("find", {"query": args.query, "count": len(res)})
    if not res:
        print("No results.")
        return
    for m in res[:200]:
        print(f"{m['file']}:{m['line']}  {m['text']}")
    if len(res) > 200:
        print(f"... {len(res)-200} more results truncated")

def cmd_propose_fix(args):
    # This is a stub: we generate a patch file slot for your editor/agent to fill.
    proposal_dir = REPO_ROOT / ".branchbot" / "proposals"
    proposal_dir.mkdir(parents=True, exist_ok=True)
    target = args.target
    summary = args.summary or "Proposed fix"
    content = {
        "target": target,
        "summary": summary,
        "instructions": "Agent should generate a unified diff patch for the target file(s) and store as .patch alongside this metadata. Human review required before apply."
    }
    meta_path = proposal_dir / f"proposal_{datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}.json"
    meta_path.write_text(json.dumps(content, indent=2))
    audit("propose_fix", content)
    print(f"Created proposal stub: {meta_path}")
    print("Open in VS Code and let your agent/extension produce the patch for review.")

def cmd_apply(args):
    patch_path = Path(args.patch)
    if not patch_path.exists():
        print("Patch file not found")
        sys.exit(1)
    # Apply patch using 'git apply --index' to stage changes for review
    try:
        subprocess.check_call(["git","apply","--index",str(patch_path)])
        audit("apply_patch", {"patch": str(patch_path)})
        print("Patch applied and staged. Review with 'git diff --staged'.")
    except subprocess.CalledProcessError as e:
        print("Failed to apply patch:", e)
        sys.exit(e.returncode)

def cmd_run_tests(args):
    # Basic test runner stub; adapt to your stack
    test_cmd = args.cmd or "pytest -q"
    print(f"Running tests: {test_cmd}")
    rc = subprocess.call(test_cmd, shell=True)
    audit("run_tests", {"cmd": test_cmd, "returncode": rc})
    sys.exit(rc)

def build_parser():
    p = argparse.ArgumentParser(prog="branchbot", description="BranchBot CLI (propose-only by default)")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("status"); s.set_defaults(func=cmd_status)
    s = sub.add_parser("find"); s.add_argument("query"); s.set_defaults(func=cmd_find)
    s = sub.add_parser("propose-fix"); s.add_argument("target"); s.add_argument("--summary"); s.set_defaults(func=cmd_propose_fix)
    s = sub.add_parser("apply"); s.add_argument("patch"); s.set_defaults(func=cmd_apply)
    s = sub.add_parser("run-tests"); s.add_argument("--cmd"); s.set_defaults(func=cmd_run_tests)
    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
