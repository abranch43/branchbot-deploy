# BranchBot Agent Mode Starter

**Generated:** 2025-09-17T17:01:07.152353Z

## What you got
- `agent-permissions.yml` — permission & escalation policy (propose-only by default).
- `branchbot_cli/main.py` — minimal CLI (find, propose-fix stub, apply patch, run-tests) with audit logs.
- `.vscode/settings.json` — safe defaults (preview edits, whisper on).
- `.github/workflows/branchbot-ci.yml` — CI scaffold to run tests and upload .branchbot artifacts.

## Quick start
```bash
# 1) Put this folder at the root of your repo
cp -r branchbot_agent_mode/* your-repo/

# 2) Add alias
echo "alias branchbot='python branchbot_cli/main.py'" >> ~/.bashrc && source ~/.bashrc

# 3) Try it
branchbot status
branchbot find "TODO"
branchbot propose-fix src/example.py --summary "Refactor example"
# Agent (editor extension) generates a patch file into .branchbot/proposals/*.patch
branchbot apply .branchbot/proposals/<your.patch>
```

## Policy changes
Edit `agent-permissions.yml`. Start read-only; grant `propose_only` to trusted agents; keep escalations for prod deploys, migrations, secrets.

## Voice control
Your editor plugin should map a whisper hotkey to shell commands like:
- `branchbot find "<query>"`
- `branchbot propose-fix "<file|glob>" --summary "<goal>"`

