
# scripts/social_post_out.py
import os, yaml, pathlib

CFG = "config/gumroad.config.yaml"
out_dir = "rendered_social"
os.makedirs(out_dir, exist_ok=True)

with open(CFG, "r", encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

pay = cfg.get("social",{}).get("ctas",{}).get("pay_link","")
bundle = cfg.get("social",{}).get("ctas",{}).get("gumroad_bundle_url","")

def sub(text):
    return text.replace("{PAY_LINK}", pay).replace("{GUMROAD_BUNDLE_URL}", bundle)

ln = cfg.get("social",{}).get("linkedin",{}).get("pin_post","")
x = cfg.get("social",{}).get("x",{}).get("pin_post","")

open(f"{out_dir}/linkedin_pin.txt","w",encoding="utf-8").write(sub(ln).strip()+"
")
open(f"{out_dir}/x_pin.txt","w",encoding="utf-8").write(sub(x).strip()+"
")

print("Rendered social copy in ./rendered_social/")
