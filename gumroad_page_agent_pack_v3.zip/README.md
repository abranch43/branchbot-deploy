
# Gumroad Page Agent v3 — with Auto-PR

This version:
- Syncs Gumroad products (API) and bundles (Playwright fallback)
- Renders social copy (LinkedIn & X) with your CTA links
- **Opens a Pull Request** adding `rendered_social/x_pin.txt` and `rendered_social/linkedin_pin.txt`

## Use
1) Add to your repo (e.g., `ops/gumroad-agent/`).
2) Add Repo Secrets: `GUMROAD_ACCESS_TOKEN`, `GUMROAD_EMAIL`, `GUMROAD_PASSWORD`.
3) Edit `config/gumroad.config.yaml` (update your PayPal link + bundle URL).
4) Push or run the workflow. A PR will appear with your social posts ready to paste.

## Notes
- Requires `permissions: contents: write, pull-requests: write` (already set).
- Base branch defaults to `main`. Adjust `GITHUB_BASE_REF` if needed.
